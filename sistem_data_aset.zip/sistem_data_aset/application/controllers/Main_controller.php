<?php

/**
* @author 		author
* @package 		Codeigniter, php 7
* @license 		http://codeigniter.com/user_guide/license.html
**/


// ---------------------------------------------------------------------------------

/**
*
*
* Ini untuk controller utama yang akan mengatur semua halaman
*
*/

class Main_controller extends MY_Controller // controller dengan class Main_controller
{


	// konstruktur
	function __construct()
	{
		parent::__construct();


		// array model

		// array helper
		$array_heper = array(
					'date_helper'
			);

		$this->load->helper($array_heper);
		// array library

		// mengambil model
		$this->load->model('upload_model');
		$this->load->model('Data_model', 'data');
		$this->load->model('File_model', 'file');
		$this->load->model('file_model');
		$this->load->model('user_model');

		// Global Variable
		$this->user_id 			= $this->logged_data('id');
		$this->user_fullname	= $this->logged_data('fullname');
		$this->user_username 	= $this->logged_data('username');
		$this->user_perm 		= $this->logged_data('perm');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));

	}

//---------------------------------------------------------------------------------------------------------------------------------------
	// fungsi free user
	public function access_guest()
	{
		$sess_array = $arrayName = array('id' => '0', 'fullname' => 'Anonim', 'username' => 'Anonim', 'perm' => 'guest');
		$this->session->set_userdata('logged_in', $sess_array);

		redirect('home');
	}

//---------------------------------------------------------------------------------------------------------------------------------------
	// fungsi index / Home
	public function index()
	{
		// cek jika user sudah login atau belum
		if($this->is_logged_in())
		{
			// Data user
			$data['id'] 		= $this->user_id;
			$data['fullname']	= $this->user_fullname;
			$data['username']	= $this->user_username;
			$data['perm'] 		= $this->user_perm;

			// Data kontent
			$data['title']		= 'Home';
			$data['header'] 	= 'Profil Perusahaan';

			// Data view
			$data['nav']		= $this->load->view("template/nav", $data, TRUE);
			$data['content']	= $this->load->view("vhome", $data, TRUE);

			// memgambil template
			$this->template($data);			
		}
		else
		{
			echo "<script>alert('Maaf Anda tidak punya akses');window.location.href='".base_url()."login';</script>";
		}
	}
//---------------------------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------------------------
	// fungsi Data APJ
	public function apj()
	{
		// cek jika user sudah login atau belum
		if($this->is_logged_in())
		{
			// Data user
			$data['id'] 		= $this->user_id;
			$data['fullname']	= $this->user_fullname;
			$data['username']	= $this->user_username;
			$data['perm'] 		= $this->user_perm;
			$data['bulan'] = array(
				'1' => 'JANUARI',
				'2' => 'FEBRUARI',
				'3' => 'MARET',
				'4' => 'APRIL',
				'5' => 'MEI',
				'6' => 'JUNI',
				'7' => 'JULI',
				'8' => 'AGUSTUS',
				'9' => 'SEPTEMBER',
				'10' => 'OKTOBER',
				'11' => 'NOVEMBER',
				'12' => 'DESEMBER',
			);


			for ($i=1990; $i <= date("Y"); $i++) 
								{ 			
								
									$data['tahun'][$i] = $i;
								
								}

			// Data konten
			$data['title'] 		= 'Data APJ';
			$data['header'] 	= 'Data Berdasarkan Bulan / Tahun 2017';
			// Data view
			$data['nav']		= $this->load->view("template/nav", $data, TRUE);
			$data['content']	= $this->load->view("data_apj", $data, TRUE);

			// memgambil template
			$this->template($data);			
		}
		else
		{
			echo "<script>alert('Maaf Anda tidak punya akses');window.location.href='".base_url()."login';</script>";
		}
	}
		// child function
		// fungsi data_apj
		function data_apj($month, $year)
		{
			// cek jika user sudah login atau belum
			if($this->is_logged_in())
			{
				// Data user
				$data['id'] 		= $this->user_id;
				$data['fullname']	= $this->user_fullname;
				$data['username']	= $this->user_username;
				$data['perm'] 		= $this->user_perm;

				// Data kontent
				$data['title']		= "Data Bulan".month($month);
				$data['header'] 	= "DATA BULAN ".month($month);
				$data['month'] 		= month($month);
				$data['year'] 		= $year;
				$data['getmonth']   = $month;
				$data['data'] 		= $this->data->list_entry($month, $year, $this->user_perm);

				$file = $this->file->list_id($month, $year);
				if ($file) {
					foreach ($file as $f)
						$data['file'] = $f->nama.'.'.$f->ekstensi;
				}
				else
				{
					$data['file'] = "";
				}

				// Data view
				$data['nav']		= $this->load->view("template/nav", $data, TRUE);
				$data['content']	= $this->load->view("data_apj_per_bulan", $data, TRUE);

				// memgambil template
				$this->template($data);			
			}
			else
			{
				echo "<script>alert('Maaf Anda tidak punya akses');window.location.href='".base_url()."login';</script>";
			}
		}
//---------------------------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------------------------
		// FUNGSI UPLOAD
		public function data_upload()
		{
			// cek jika user sudah login atau belum
			if($this->is_logged_in())
			{
				// Data user
				$data['id'] 		= $this->user_id;
				$data['fullname']	= $this->user_fullname;
				$data['username']	= $this->user_username;
				$data['perm'] 		= $this->user_perm;

				// Data kontent
				$data['title']		= 'List File';
				$data['header'] 	= "Arsip Data";
				$data['files'] 		= $this->file->list_entry();

				// Data view
				$data['nav']		= $this->load->view("template/nav", $data, TRUE);
				$data['content']	= $this->load->view('upload_list', $data, TRUE);

				// memgambil template
				$this->template($data);			
			}
			else
			{
				echo "<script>alert('Maaf Anda tidak punya akses');window.location.href='".base_url()."login';</script>";
			}	
		}

			// child function

			// fungsi upload data
			function form_upload()
			{
				// cek jika user sudah login atau belum
				if($this->is_logged_in())
				{
					// Data user
					$data['id'] 		= $this->user_id;
					$data['fullname']	= $this->user_fullname;
					$data['username']	= $this->user_username;
					$data['perm'] 		= $this->user_perm;

					// Data kontent
					$data['title']		= 'Form Upload';
					$data['header'] 	= "Form Upload";
					$data['bulan'] 		= array(
								'1' => 'JANUARI',
								'2' => 'FEBRUARI',
								'3' => 'MARET',
								'4' => 'APRIL',
								'5' => 'MEI',
								'6' => 'JUNI',
								'7' => 'JULI',
								'8' => 'AGUSTUS',
								'9' => 'SEPTEMBER',
								'10' => 'OKTOBER',
								'11' => 'NOVEMBER',
								'12' => 'DESEMBER',
					);

					for ($i=1990; $i <= date("Y"); $i++) 
					{ 			
					
						$data['tahun'][$i] = $i;
					
					}

					// Data view
					$data['nav']		= $this->load->view("template/nav", $data, TRUE);
					$data['content'] 	= $this->load->view("upload", $data, TRUE);

					// memgambil template
					$this->template($data);			
				}
				else
				{
					echo "<script>alert('Maaf Anda tidak punya akses');window.location.href='".base_url()."login';</script>";
				}	
			}

			// fungsi proses upload
			function upload_process()
			{
				$do_upload = $this->upload_model->process();

				echo "<script>alert('".$do_upload."');window.location.href='".base_url()."upload"."';</script>";
				//redirect('upload');

			}

			//fungsi export ke excel
			function export_excel($month)
			{
				// Data kontent
				$data['title']		= 'upload';
				$data['header'] 	= "Data Bulan ".month($month);
				$data['month'] 		= month($month);
				$data['data'] 		= $this->data->list_entry($month, '2017', $this->user_perm);

				$file = $this->file->list_id($month, '2017');
				if ($file) {
					foreach ($file as $f)
						$data['file'] = $f->nama.'.'.$f->ekstensi;
				}
				else
				{
					$data['file'] = "";
				}

				// Data view
				$data['nav']		= '';
				$data['content']	= $this->load->view("export_excel", $data, TRUE);

				// memgambil template
				$this->load->view('base', $data);
				
				// Load the table view into a variable
				$html = $this->load->view('base', $data, true);

				// Put the html into a temporary file
				$tmpfile = time().' '.$month.'-2017.xlsx';
				file_put_contents('assets/download/'.$tmpfile, $html);

				// Read the contents of the file into PHPExcel Reader class
				$reader = new PHPExcel_Reader_HTML; 
				$content = $reader->load('assets/download/'.$tmpfile); 

				// Pass to writer and output as needed
				$objWriter = IOFactory::createWriter($content, 'Excel2007');
				ob_end_clean();
				header('Content-type: application/vnd.ms-excel');
				header('Content-Disposition: attachment; filename="'.$tmpfile.'"');
				$objWriter->save('php://output');

				// Delete temporary file
			}

			function print_excel($month)
			{
				// Data kontent
				$data['title']		= 'print';
				$data['header'] 	= "Data Bulan ".month($month);
				$data['month'] 		= month($month);
				$data['data'] 		= $this->data->list_entry($month, '2017', $this->user_perm);

				$file = $this->file->list_id($month, '2017');
				if ($file) {
					foreach ($file as $f)
						$data['file'] = $f->nama.'.'.$f->ekstensi;
				}
				else
				{
					$data['file'] = "";
				}

				// Data view
				$data['nav']		= '';
				$data['content']	= $this->load->view("export_excel", $data, TRUE);

				// memgambil template
				$this->load->view('base', $data);
			}

			function delete_data($file)
			{
				$do_del = $this->file_model->delete_data($file);

				$bu = base_url();

				echo "<script>alert('Data berhasil di hapus');window.location.href='".$bu."listfile';</script>";
			}

//---------------------------------------------------------------------------------------------------------------------------------------

//---------------------------------------------------------------------------------------------------------------------------------------
		// FUNGSI ADMIN STAF

		public function admin_staff()
		{
			// cek jika user sudah login atau belum
			if($this->is_logged_in())
			{
				// Data user
				$data['id'] 		= $this->user_id;
				$data['fullname']	= $this->user_fullname;
				$data['username']	= $this->user_username;
				$data['perm'] 		= $this->user_perm;

				// Data kontent
				$data['title']		= 'Admin / Staff';
				$data['header'] 	= "Data Admin / Staff";
				$data['user_data'] 	= $this->user_model->load_data();

				// Data view
				$data['nav']		= $this->load->view("template/nav", $data, TRUE);
				$data['content']	= $this->load->view('data_astaff', $data, TRUE);

				// memgambil template
				$this->template($data);			
			}
			else
			{
				echo "<script>alert('Maaf Anda tidak punya akses');window.location.href='".base_url()."login';</script>";
			}	
		}

			// view tambah user
			function view_add_admin_staff()
			{
				$this->load->view('add_astaff');
			}

			// view edit user
			function view_edit_admin_staff($key)
			{
				$data['user_data'] = $this->user_model->load_data_by_username($key);
				$this->load->view('edit_astaff', $data);
			}

			// simpan tambah user
			function save_admin_staff()
			{
				$do_save = $this->user_model->save_data();

				echo $do_save;
			}

			// hapus user
			function delete_admin_staff($key)
			{
				$do_del   = $this->user_model->delete_data($key);

				echo $do_del;
			}



// Akhir controller	
}


?>