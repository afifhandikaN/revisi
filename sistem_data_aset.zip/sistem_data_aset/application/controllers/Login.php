<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_controller {

	public function index()
	{	
		$this->form_validation->set_rules('username','Username','trim|required');
		$this->form_validation->set_rules('password','Password','trim|required|callback_basisdata_cek');
		if($this->form_validation->run()==false){
			$this->load->view('login_view');
		} else{
			redirect(base_url('home'), 'refresh');
		}
	}

	public function logout()
	{
		session_destroy();
		echo "<script>alert('Anda telah logout dan akan di alihkan ke login'); window.location.href='".base_url()."login';</script>";
	}

	function basisdata_cek($password)
	{
		$username 	= $this->input->post('username');
		$password   = $this->input->post('password');

		// cek jika username dan password terset atau tidak
		if(isset($username) && isset($password))
		{
			$result 	= $this->Login->login($username,$password);

			if($result>0)
			{
				$sess_array = array();
				foreach ($result as $row) 
				{
					$sess_array = $arrayName = array('id' => $row->id, 'fullname' => $row->fullname, 'username' => $row->username, 'perm' => $row->perm);
					$this->session->set_userdata('logged_in', $sess_array);
			

					if($row->perm == 'admin')
					{
						echo "<script>alert('Selamat datang ".strtoupper('Admin area Mojokerto')."');</script>";
					}
					else
					{
						echo "<script>alert('Selamat datang Rayon ".strtoupper($row->perm)."');</script>";
					}

				return true;
				}

				
			} else{
				$this->form_validation->set_message('basisdata_cek','invalid username or password (Nama dan Kata Sandi SALAH)');
				return false;	
			}
		}

	}

// akkhir controller
}
