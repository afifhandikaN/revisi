<?php
class File_model extends CI_Model {

    public $tanggal_upload;
    public $nama;
    public $ekstensi;
    public $bulan;
    public $tahun;
    
    // public function get_last_ten_entries()
    // {
    //     $query = $this->db->get('entries', 10);
    //     return $query->result();
    // }

    public function insert_entry($data)
    {
        $this->nama = $data['nama'];
        $this->judul = $data['judul'];
        $this->tanggal_upload = $data['tanggal_upload'];
        $this->ekstensi = $data['ekstensi'];
        $this->keterangan = $data['keterangan'];
        $this->bulan = $data['bulan'];
        $this->tahun = $data['tahun'];
        
        
        $this->db->insert('file', $this);
        
        $insert_id = $this->db->insert_id();
        return  $insert_id;
    }

    public function list_entry(){
        $this->db->select('*');
        $this->db->order_by('id', 'desc');
        $files = $this->db->get("file")->result();
        return $files;
    }

    public function list_id($bulan, $tahun){        
        $files = $this->db->query("SELECT * FROM file WHERE bulan=$bulan AND tahun=$tahun ORDER BY id DESC LIMIT 1")->result();
        return $files;
    }

    public function delete_data($file)
    {
        $rep  = array('.xlsx', '.xls', '.csv');
        $name = str_replace($rep, '', $file);

        $this->db->select('*');
        $this->db->from('file');
        $this->db->where('nama', $name);

        $queryFile = $this->db->get()->result();

        foreach($queryFile as $rowFile)
        {
            $namefile = $rowFile->nama;
            $ext      = $rowFile->ekstensi;
        }

        unlink('assets/excel/'.$namefile.'.'.$ext);

        $this->db->where('nama', $name);
        $this->db->delete('file');

        echo "Data berhasil dihapus";
    }
    // public function update_entry()
    // {
    //     $this->title    = $_POST['title'];
    //     $this->content  = $_POST['content'];
    //     $this->date     = time();

    //     $this->db->update('entries', $this, array('id' => $_POST['id']));
    // }

}