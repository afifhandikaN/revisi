<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

	function Login($username, $password)
	{	
		$password  = md5($password);

		$query = $this->db->query("select * from user where username = '$username' and password = '$password'");

		return $query->result();
	}
}
