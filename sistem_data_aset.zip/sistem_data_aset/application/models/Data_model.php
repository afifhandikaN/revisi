<?php
class Data_model extends CI_Model {

	public function insert_entry($data){
		$this->db->insert_batch('data', $data);
	}

	public function list_entry($bulan, $year, $perm){
		// SELECT * FROM data WHERE id IN(
		//     SELECT MAX(id) FROM data GROUP BY rayon
		// ) AND bulan = $bulan AND tahun = $year

		// kondisi untuk menentukan data apj yang akan di tampilkan
		if($perm == 'guest')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();
		}

		if($perm == 'admin')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'mja')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'mjk')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'jbg')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'ngr')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'pls')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'mjs')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'pct')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'kts')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'wrj')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

		if($perm == 'ngk')
		{
			$query = $this->db->query("SELECT * FROM data WHERE id IN(SELECT MAX(id) FROM data WHERE rayon = '$perm' AND bulan = $bulan AND tahun = $year GROUP BY rayon)");
			return $query->result();		
		}

	}

	public function cek_count_data($bulan, $tahun){
		$this->db->from('data');
		$this->db->where('bulan', $bulan);
		$this->db->where('tahun', $tahun);
		$query = $this->db->get();
		$rowcount = $query->num_rows();

		return $rowcount;
	}
}