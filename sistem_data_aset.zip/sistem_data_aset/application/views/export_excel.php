    <link href="<?= base_url() ?>assets/admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?= base_url() ?>assets/admin//vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?= base_url() ?>assets/admin//dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?= base_url() ?>assets/admin//vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <script src="<?= base_url() ?>assets/admin/vendor/jquery/jquery.min.js"></script>


<style type="text/css" align="text-center">

table
    {
        border-collapse: collapse;
        width: 100%;
    }

table th
    {
        border: 1px solid#000;
        text-align: center;
    }

table td
    {
        border:  1px solid#000;
    }

@media print {
  #printBtn {
    display: none;
  }
}

</style>
                    <table>
                    <thead>
                        <tr>
                        <td colspan="17" align="center"><strong><b>DATA ASET DISTRIBUSI BULAN <?= $month.' 2017' ?></b></strong></td>
                        </tr>
                        <tr>
                        <th rowspan="3" align="center">RAYON</th>
                        <th rowspan="3" align="center">JUMLAH PENYULANG</th>
                        <th rowspan="3" align="center">PJ_SUTM</th>
                        <th rowspan="3" align="center">TIANG_TM</th>
                        <!--header -->
                        <td colspan="9" align="center"><strong> GARDU </strong></td>
                        <!--/header -->
                        <th rowspan="3" align="center">PJ_SUTR</th>
                        <th rowspan="3" align="center">TIANG_TR</th>
                        <th rowspan="3" align="center">PJ_SR</th>
                        <th rowspan="3" align="center">(KM2)</th>
                        </tr>
                        <tr>
                        <th colspan="3" align="center">PLN</th>
                        <th colspan="3" align="center">PELANGGAN</th>
                        <th colspan="3" align="center">TOTAL</th>
                        </tr>
                        <!--pln-->
                        <tr>
                        <th align="center">Unit</th>
                        <th align="center">Buah</th>
                        <th align="center">JML_KVA</th>
                        <!--/pln-->
                        <!--pelanggan-->
                        <th align="center">Unit</th>
                        <th align="center">Buah</th>
                        <th align="center">JML_KVA</th>
                        <!--/pelanggan-->
                        <!--total-->
                        <th align="center">Unit</th>
                        <th align="center">Buah</th>
                        <th align="center">JML_KVA</th>
                        </tr>
                        <!--/total-->
                        </thead>
                            <tbody>
                            <?php
                            $sum_jmh_plyg = $sum_pj_sutm = $sum_tiang_tm = $sum_pln_unit = $sum_pln_buah = $sum_pln_jml_kva = 0;
                            $sum_pel_unit = $sum_pel_buah = $sum_pel_jml_kva = 0;
                            $sum_total_unit = $sum_total_buah = $sum_total_jml_kva = 0;
                            $sum_pj_sutr = $sum_tiang_tr = $sum_pj_sr = $sum_km2 = 0;
                            foreach ($data as $value) {
                                $sum_jmh_plyg += $value->jmh_pylg;
                                $sum_pj_sutm += $value->pj_sutm;
                                $sum_tiang_tm += $value->tiang_tm;
                                $sum_pln_unit += $value->pln_unit;
                                $sum_pln_buah += $value->pln_buah;
                                $sum_pln_jml_kva += $value->pln_jml_kva;
                                $sum_pel_unit += $value->pel_unit;
                                $sum_pel_buah += $value->pel_buah;
                                $sum_pel_jml_kva += $value->pel_jml_kva;
                                $sum_total_unit += $value->total_unit;
                                $sum_total_buah += $value->total_buah;
                                $sum_total_jml_kva += $value->total_jml_kva;
                                $sum_pj_sutr += $value->pj_sutr;
                                $sum_tiang_tr += $value->tiang_tr;
                                $sum_pj_sr += $value->pj_sr;
                                $sum_km2 += $value->km2;                                
                                ?>
                                <tr>
                                    <td><?= $value->rayon ?></td>
                                    <td><?= number_format($value->jmh_pylg,0,",",".") ?></td>
                                    <td><?= number_format($value->pj_sutm,0,",",".") ?></td>
                                    <td><?= number_format($value->tiang_tm,0,",",".") ?></td>
                                    <td><?= number_format($value->pln_unit,0,",",".") ?></td>
                                    <td><?= number_format($value->pln_buah,0,",",".") ?></td>
                                    <td><?= number_format($value->pln_jml_kva,0,",",".") ?></td>
                                    <td><?= number_format($value->pel_unit,0,",",".") ?></td>
                                    <td><?= number_format($value->pel_buah,0,",",".") ?></td>
                                    <td><?= number_format($value->pel_jml_kva,0,",",".") ?></td>
                                    <td><?= number_format($value->total_unit,0,",",".") ?></td>
                                    <td><?= number_format($value->total_buah,0,",",".") ?></td>
                                    <td><?= number_format($value->total_jml_kva,0,",",".") ?></td>
                                    <td><?= number_format($value->pj_sutr,0,",",".") ?></td>
                                    <td><?= number_format($value->tiang_tr,0,",",".") ?></td>
                                    <td><?= number_format($value->pj_sr,0,",",".") ?></td>
                                    <td><?= number_format($value->km2,0,",",".") ?></td>
                                </tr>
                                <?php
                            }
                            ?>
                                <tr>
                                    <td><b>TOTAL</b></td>
                                    <td><?= number_format($sum_jmh_plyg,0,",",".") ?></td>
                                    <td><?= number_format($sum_pj_sutm,0,",",".") ?></td>
                                    <td><?= number_format($sum_tiang_tm,0,",",".") ?></td>
                                    <td><?= number_format($sum_pln_unit,0,",",".") ?></td>
                                    <td><?= number_format($sum_pln_buah,0,",",".") ?></td>
                                    <td><?= number_format($sum_pln_jml_kva,0,",",".") ?></td>
                                    <td><?= number_format($sum_pel_unit,0,",",".") ?></td>
                                    <td><?= number_format($sum_pel_buah,0,",",".") ?></td>
                                    <td><?= number_format($sum_pel_jml_kva,0,",",".") ?></td>
                                    <td><?= number_format($sum_total_unit,0,",",".") ?></td>
                                    <td><?= number_format($sum_total_buah,0,",",".") ?></td>
                                    <td><?= number_format($sum_total_jml_kva,0,",",".") ?></td>
                                    <td><?= number_format($sum_pj_sutr,0,",",".") ?></td>
                                    <td><?= number_format($sum_tiang_tr,0,",",".") ?></td>
                                    <td><?= number_format($sum_pj_sr,0,",",".") ?></td>
                                    <td><?= number_format($sum_km2,0,",",".") ?></td>
                                </tr>
                            </tbody>
                        </table>

<br>


<div class="btn-wrapper" style="width: 100%; padding: 5px; text-align: center;">

    <button id="printBtn" class="btn btn-primary"><span class="fa fa-download"></span> Print</button>

</div>

<script type="text/javascript">

$('#printBtn').on('click', function(){

    window.print();

});

</script>
                