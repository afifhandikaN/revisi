<div class="row">
    <div class="col-lg-12">
            <div class="conten">        
               <!--  <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1"> -->
  <div class="col-lg-12 col-md-12 col-xs-12">
<h4 style="text-align: justify">Visi</h4>
<p style="text-align: justify">Diakui sebagai Perusahaan Kelas Dunia yang Bertumbuh kembang, Unggul dan terpercaya dengan bertumpu pada Potensi Insani.</p>
<h4 style="text-align: justify">Misi</h4>
<ul class="align-side" style="text-align: justify">
<li>Menjalankan bisnis kelistrikan dan bidang lain yang terkait, berorientasi pada kepuasan pelanggan, anggota perusahaan dan pemegang saham.</li>
<li>Menjadikan tenaga listrik sebagai media untuk meningkatkan kualitas kehidupan masyarakat.</li>
<li>Mengupayakan agar tenaga listrik menjadi pendorong kegiatan ekonomi.</li>
<li>Menjalankan kegiatan usaha yang berwawasan lingkungan.</li>
</ul>
<h4 style="text-align: justify">Moto</h4>
<p style="text-align: justify">Listrik untuk Kehidupan yang Lebih Baik</p>
<h4 style="text-align: justify">Maksud dan Tujuan Perseroan</h4>
<p style="text-align: justify">Untuk menyelenggarakan usaha penyediaan tenaga listrik bagi kepentingan umum dalam jumlah dan mutu yang memadai serta memupuk keuntungan dan melaksanakan penugasan Pemerintah di bidang ketenagalistrikan dalam rangka menunjang pembangunan dengan menerapkan prinsip-prinsip Perseroan Terbatas</p>
<h4 style="text-align: justify">Sejarah PLN</h4>
<p style="text-align: justify">Berawal di akhir abad 19, bidang pabrik gula dan pabrik ketenagalistrikan di Indonesia mulai ditingkatkan saat beberapa perusahaan asal Belanda yang bergerak di bidang pabrik gula dan pebrik teh mendirikan pembangkit tenaga lisrik untuk keperluan sendiri</p>
<p style="text-align: justify">Antara tahun 1942-1945 terjadi peralihan pengelolaan perusahaan-perusahaan Belanda tersebt oleh Jepang, setelah Belanda menyerah kepada pasukan tentara Jepang di awal Perang Dunia II</p>
<p style="text-align: justify">Proses peralihan kekuasaan kembali terjadi di akhir Perang Dunia II pada Agustus 1945, saat Jepang menyerah kepada Sekutu. Kesempatan ini dimanfaatkan oleh para pemuda dan buruh listrik melalui delagasi Buruh/Pegawai Listrik dan Gas yang bersama-sama dengan Pemimpin KNI Pusat berinisiatif menghadap Presiden Soekarno untuk menyerahkan perusahaan-perusahaan tersebut kepada Pemerintah Republik Indinesia. Pada 27 Oktober 1945, Presiden Soekarno membentuk Jawatan Listrik dan Gas di bawah Departemen Pekerjaan Umum dan Tenaga dengan kapasitas pembangkit tenaga listrik sebesar 157,5 MW.</p>
<p style="text-align: justify">Pada tanggal 1 januari 1961, Jawatan Listrik dan Gas diubah menjadi BPU-PLN (Bada Pemimpin Umum Perusahaan Listrik Negara) yang bergerak di bidang listrik, gas dan kokas yang dibubarkan pada tanggal 1 Januari 1965. Pada saat yang sama, 2 (dua) perusahaan negara yaitu Perusahaan Listrik Negara (PLN) sebagai pengelola tenaga listrik milik negara dan Perusahaan Gas Negara (PGN) sebagai pengelola gas diresmikan.</p>
<p style="text-align: justify">Pada tahun 1972, sesuai dengan Peraturan Pemerintah No. 17, status Perusahaan Listrik Negara (PLN) ditetapkan sebagai Perusahaan Umum Listrik Negara dan sebagai Pemegang Kuasa Usaha Ketenagalistrikan (PKUK) dengan tugas menyediakan tenaga listrik bagi kepentingan umum.</p>
<p style="text-align: justify">Seiring dengan kebijakan Pemerintah yang memberikan kesempatan kepada sektor swasta untuk bergerak dalam bisnis penyediaan listrik, maka sejak tahun 1994 status PLN beralih dari Perusahaan Umum menjadi Perusahaan Perseroan (Persero) dan juga sebagai PKUK dalam menyediakan listrik bagi kepentingan umum hingga sekarang</p><br>
<p style="text-align: left"><strong>Alamat PT PLN (Persero)</strong><br>
Jalan Trunojoyo Blok M – I No 135<br>
Kebayoran Baru, Jakarta 12160, Indonesia<br>
Telp : 021 – 7251234, 7261122<br>
fax : 021 – 7221330</p>
</div>
            </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /row -->
</div>

<hr>
<p class="text-center">Copyright &copy; 2017 PT PLN (Persero) All Rights Reserved</p>
<!-- Footer -->
<div class="row">
    <div class="col-lg-12">
            <div class="row">          
                <div class="col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1">
                    <ul class="list-inline text-center">
                        <li>
                            <a href="#">
                                <span class="fa-stack fa-lg">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-twitter fa-stack-1x fa-inverse"></i>
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="fa-stack fa-lg">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-facebook fa-stack-1x fa-inverse"></i>
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="fa-stack fa-lg">
                                    <i class="fa fa-circle fa-stack-2x"></i>
                                    <i class="fa fa-github fa-stack-1x fa-inverse"></i>
                                </span>
                            </a>
                        </li>
                    <!-- <p class="copyright text-muted">Copyright &copy; Your Website 2016</p> -->
                    </ul>
                </div>                            
                <!-- /.col-lg-4 (nested) -->
            </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /row -->
</div>


