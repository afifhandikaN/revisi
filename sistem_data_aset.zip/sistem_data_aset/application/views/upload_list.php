<div class="row">
    <div class="col-lg-12">
<!--         <button id="addUser" class="btn btn-success"><i class="fa fa-plus"></i> Tambah Admin / Staff</button>
        <br>
        <Br> -->
        <div class="panel panel-default">
            <div class="panel-heading"><strong>Arsip Data</strong></div>
            <div class="panel-body">
                <table class="table table-striped table-bordered table-hover" id="dataTables-file">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Tanggal Upload</th>
                            <th>Nama File</th>
                            <th>Ekstensi File</th>
                            <th>Keterangan</th>
                            <th>Tahun / Bulan</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php 
                    $i = 1;
                    foreach ($files as $key => $value) { 
                        ?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= $value->tanggal_upload ?></td>
                            <td><?= $value->judul ?></td>
                            <td><?= $value->ekstensi ?></td>
                            <td><?= $value->keterangan ?></td>
                            <td><?= $value->tahun.' / '.$value->bulan ?></td>
                            <td align="center"><a href="<?php echo base_url();?>assets/excel/<?= $value->nama.'.'.$value->ekstensi ?>" class="btn btn-success"><i class="fa fa-download"></i></a>&nbsp&nbsp&nbsp 
                            <?php if($perm == 'admin'):?>
                            <a href="<?php echo base_url();?>main_controller/delete_data/<?= $value->nama.'.'.$value->ekstensi ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                            <?php endif;?>
                            </td>
                        </tr>
                    <?php 
                        $i++;
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>