<script src="<?= base_url() ?>assets/admin/vendor/jquery/jquery.min.js"></script>

                        <div class="form-group">
                            <label> Data Tahun ke </label><br>
                            <?php
                            echo form_dropdown('tahun', $tahun, date("Y"), ['class'=>'form-control year']);
                            ?>
                        </div>

<br>

<div class="row">
<?php
foreach ($bulan as $key => $value) {
?>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-tasks fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
                        <div class="huge"><?= $key ?></div>
                        <div><bold> <?= $value ?> </bold></div>
                    </div>
                </div>
            </div>
            <a id="viewApj" href="<?= base_url() ?>apj/bulan/<?= $key ?>">
                <div class="panel-footer">
                    <span class="pull-left">View Data</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
<?php
}
?>    
</div>
<!-- /.row -->

<script type="text/javascript">
    
$(document).on('click', '#viewApj', function(){
    
    link = $(this).attr('href');
    year = $('.year').val();

    window.location.href=link+'/'+year;
    return false;

});

</script>