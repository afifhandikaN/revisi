
<div class="row">
                    <div class="col-lg-12">
                        <?= $content ?>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>