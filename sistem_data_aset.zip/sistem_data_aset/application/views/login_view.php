<!DOCTYPE html>
<html lang="en">
<head>
<style> 
body {
    margin: 0 auto;
    background-image: url("assets/img/2.jpg");
    background-repeat: no-repeat;
    background-size: 1380px 675px;
}
.container{
    width: 400px;
    height: 400px;
    text-align: center;
}
</style>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PT.PLN AREA MOJOKERTO</title>

    <link href="<?= base_url() ?>assets/img/Logo_PLN.png" rel="canonical shortcut icon">



    <!-- Bootstrap Core CSS -->
    <link href="<?= base_url() ?>assets/admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?= base_url() ?>assets/admin//vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?= base_url() ?>assets/admin//dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?= base_url() ?>assets/admin//vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>



    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Please Sign In</h3>
                    </div>
                    <div class="panel-body">

                    <?php
                    if(validation_errors()){
                    ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
					  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					  <strong><?php echo validation_errors(); ?></strong>
					</div>
                    <?php
                	}
                    ?>

                        <form action="<?php echo site_url('Login')?>" method="post" role="form">
                            <fieldset>
                                <div class="form-group">
                                	<label form="exampleinputusername">Username</label>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Username"  autofocus>
                                </div>
                                <div class="form-group">
                                	<label form="exampleinputusername">Password</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                                </div>
                                <button type="submit" class="btn btn-success">Login</button>
                                <br>
                                <br>
                                Masuk sebagai free user ? <a href="access_guest">klik disini</a>
                                <br>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?= base_url() ?>assets/admin/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?= base_url() ?>assets/admin/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?= base_url() ?>assets/admin/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?= base_url() ?>assets/admin//dist/js/sb-admin-2.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?= base_url() ?>assets/admin/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="<?= base_url() ?>assets/admin/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="<?= base_url() ?>assets/admin/vendor/datatables-responsive/dataTables.responsive.js"></script>

    <script>
    $(document).ready(function() {
        $('#dataTables-file').DataTable({
            // responsive: true
        });
    });
    </script>
</body>
</html>
