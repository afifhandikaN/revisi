-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Sep 01, 2017 at 06:14 PM
-- Server version: 10.0.20-MariaDB
-- PHP Version: 5.6.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data_aset`
--

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE IF NOT EXISTS `data` (
  `id` int(11) NOT NULL,
  `rayon` varchar(50) NOT NULL,
  `kode_up` varchar(10) NOT NULL,
  `jmh_pylg` float NOT NULL,
  `pj_sutm` float NOT NULL,
  `tiang_tm` float NOT NULL,
  `pln_unit` float NOT NULL,
  `pln_buah` float NOT NULL,
  `pln_jml_kva` float NOT NULL,
  `pel_unit` float NOT NULL,
  `pel_buah` float NOT NULL,
  `pel_jml_kva` float NOT NULL,
  `total_unit` float NOT NULL,
  `total_buah` float NOT NULL,
  `total_jml_kva` float NOT NULL,
  `pj_sutr` float NOT NULL,
  `tiang_tr` float NOT NULL,
  `pj_sr` float NOT NULL,
  `km2` float NOT NULL,
  `id_file` float NOT NULL,
  `bulan` int(2) NOT NULL,
  `tahun` int(4) NOT NULL,
  `bln_thn` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE IF NOT EXISTS `file` (
  `id` int(11) NOT NULL,
  `tanggal_upload` date NOT NULL,
  `nama` varchar(120) NOT NULL,
  `judul` text NOT NULL,
  `ekstensi` varchar(5) NOT NULL,
  `keterangan` text NOT NULL,
  `bulan` int(2) NOT NULL,
  `tahun` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `perm` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullname`, `username`, `password`, `perm`) VALUES
(3, 'afifhandika', 'afif', '67efb5179e4065ee13f2368345a8d0d2', 'admin'),
(9, 'Rayon Mojoagung', 'Rmja', '5222415b64aa56958fc314abac173737', 'mja'),
(10, 'Rayon Mojokerto', 'Rmjk', '5ba07011126c736257dda8fe8b27a7ca', 'mjk'),
(11, 'Bagaswara', 'bagas', '5ffd9bb73b00bce4feeb77e2d12722da', 'admin'),
(12, 'Administrator', 'admin', '0192023a7bbd73250516f069df18b500', 'admin'),
(13, 'Rayon Jombang', 'Rjbg', '17fdd16eff68c1b3e55fa85ba1468351', 'jbg'),
(14, 'Rayon Ngoro', 'Rngr', '63dbc82005144c4a79a59b3287ca8d10', 'ngr'),
(16, 'Rayon Ploso', 'Rpls', '4a9c26c9c36259c86b6fabac3f430d6b', 'pls'),
(17, 'Rayon Mojosari', 'Rmjs', 'c22f915bb83971a4a7ece06b26d1c29f', 'mjs'),
(18, 'Rayon Pacet', 'Rpct', '301e155819449b8b21e14f68a9bb02e6', 'pct'),
(19, 'Rayon Kertosono', 'Rkts', 'dee32eebb13763806945a4a01f33d359', 'kts'),
(20, 'Rayon Warujayeng', 'Rwrj', '74bb73336573339a0867ffa485061428', 'wrj'),
(21, 'Rayon Nganjuk', 'Rngk', '77bf86bd2dfc3f631e298480e15beb3a', 'ngk');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `file`
--
ALTER TABLE `file`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
